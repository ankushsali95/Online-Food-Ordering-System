﻿using Microsoft.AspNetCore.Mvc;
//using TFLPortal.Responses;
using TFLPortal.Models;
using TFLPortal.Helpers;
using TFLPortal.Services.AdminMgmt;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Org.BouncyCastle.Crypto.Generators;



namespace Transflower.TFLPortal.Intranet.Controllers;

[ApiController]
[Route("/api")]



    public class AdminController : ControllerBase
    {
    private readonly IProductService _productService;
   

    public AdminController(IProductService productService)
    {
        _productService = productService;
    }




    

    [HttpGet("products")]
    public async Task<IActionResult> GetAllProducts()
    {
        try
        {
            List<Product> products = await _productService.GetAllProducts();
            return Ok(products);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }



    // [Authorize(RoleTypes.ProjectManager)]


    [HttpPost("addProduct")]
    public async Task<IActionResult> AddProduct(Product product)
    {
        try
        {
            bool success = await _productService.AddProduct(product);
            if (success)
            {
                return Ok("Product added successfully");
            }
            else
            {
                return BadRequest("Failed to add product");
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }







    [HttpPut("EditProduct/{id}")]
        public async Task<IActionResult> EditProduct(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest("Invalid product ID");
            }

            try
            {
                bool success = await _productService.EditProduct(product);
                if (success)
                {
                    return Ok("Product updated successfully");
                }
                else
                {
                    return NotFound("Product not found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    [HttpDelete("DeleteProduct/{id}")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        try
        {
            bool success = await _productService.DeleteProduct(id);
            if (success)
            {
                return Ok("Product deleted successfully");
            }
            else
            {
                return NotFound("Product not found");
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }


   

















}







