using Microsoft.AspNetCore.Mvc;
//using TFLPortal.Responses;
using TFLPortal.Models;
using TFLPortal.Helpers;
using TFLPortal.Services.UsersMgmt;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Org.BouncyCastle.Crypto.Generators;
using TFLPortal.Services.OrdersMgmt;


namespace Transflower.TFLPortal.Intranet.Controllers;

[ApiController]
[Route("/api")]
public class OrderController : ControllerBase
{
    private readonly IUserService _userService;
    private IOrderService _orderService;

    public OrderController(IOrderService orderService)
    {
        _orderService = orderService;
    }

    [HttpGet("orders")] 
    public async Task<IActionResult> GetAllOrders()
    {
        try
        {
            List<Orderlist> orders = await _orderService.GetAllOrders();
            return Ok(orders);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("revenue")]
    public async Task<IActionResult> singleRevenue()
    {
        try
        {
            RevenueData rv = await _orderService.singleRevenue();
            return Ok(rv);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }



    [HttpPost("createOrder")]
    public async Task<IActionResult> createOrder(Order order)
    {
        try
        {
            // Validate the order data (if needed)

            // Call the service method to create the order
            await _orderService.AddOrderWithItems(order);

            // Return a success response
            return Ok(order);
        }
        catch (Exception ex)
        {
            // Return an error response if an exception occurs
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpPost("singleOrder/{id}")]
    public async Task<IActionResult> singleOrder(int id)
    {
        try
        {
            // Validate the order data (if needed)

            // Call the service method to create the order
            OrderModel order = await _orderService.GetSingleOrderWithItemsAsync(id);

            // Return a success response
            return Ok(order);
        }
        catch (Exception ex)
        {
            // Return an error response if an exception occurs
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }






}



