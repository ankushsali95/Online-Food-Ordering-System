using Microsoft.AspNetCore.Mvc;
//using TFLPortal.Responses;
using TFLPortal.Models;
using TFLPortal.Helpers;
using TFLPortal.Services.UsersMgmt;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Org.BouncyCastle.Crypto.Generators;


 namespace Transflower.TFLPortal.Intranet.Controllers;

[ApiController]
[Route("/api")]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;
    private object _orderService;

    public UserController(IUserService userService)
    {
        _userService = userService;
    }




    [HttpGet("users")]
    public async Task<IActionResult> GetAllUsers()
    {
        try
        {
            List<User> users = await _userService.GetAllUsers();
            return Ok(users);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Failed to retrieve users: {ex.Message}");
        }
    }




    // [Authorize(RoleTypes.ProjectManager)]
    [HttpPost("signup")]
    public async Task<bool> AddUser(User user)
    {
        user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);
        bool status = await _userService.AddUser(user);
        if (status)
        {
            return true;
        }
        else
        {
            return false;
        }
        
    }




    [HttpPost("login")]
    public async Task<IActionResult> LoginAsync(LoginViewModel model)
    {
        // find password by username

        // BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        // Check if username and password match (this is a simplified example)
        var userPasswordHash = await _userService.GetUserPasswordHashAsync(model.Email);
        var role = await _userService.GetUserRole(model.Email);
        var uid = await _userService.GetUserId(model.Email);
        if (userPasswordHash != null && BCrypt.Net.BCrypt.Verify(model.Password, userPasswordHash))
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(model.Email+"securehashkey_12345678901234"); // Ensure key is at least 128 bits
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.Name, model.Email) // Use the provided username here
                }),
                Expires = DateTime.UtcNow.AddHours(1), // Token expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return Ok(new { Token = tokenString, Usertype = role, myuid = uid });
        }
        else
        {
            return Unauthorized(new { Message = "Invalid username or password." });
        }

    }


    //for password authentication
    public class LoginViewModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }


    [HttpPut("EditUser/{id}")]
    public async Task<bool> EditUser(User user)
    {
        try
        {
            // Hash the user's password before updating it in the database
            user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

            // Attempt to edit the user
            bool success = await _userService.EditUser(user);

            // Return the status of the edit operation
            return success;
        }
        catch (Exception ex)
        {
            // Handle any exceptions (e.g., database errors) by throwing or logging them
            throw new Exception($"Failed to edit user: {ex.Message}", ex);
        }
    }



    [HttpDelete("DeleteUser/{id}")]
    public async Task<bool> DeleteUser(int id)
    {
        try
        {
            // Attempt to delete the user
            bool success = await _userService.DeleteUser(id);

            // Return the status of the deletion operation
            return success;
        }
        catch (Exception ex)
        {
            // Handle any exceptions (e.g., database errors) by throwing or logging them
            throw new Exception($"Failed to delete user: {ex.Message}", ex);
        }
    }




   






}



