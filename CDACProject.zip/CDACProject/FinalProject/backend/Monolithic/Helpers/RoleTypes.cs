namespace TFLPortal.Helpers;

public class RoleTypes
{
    
    public const string Employee="Employee";
    public const string HRManager="HR Manager";
    public const string ProjectManager="Project Manager";
    public const string Director="Director";

}