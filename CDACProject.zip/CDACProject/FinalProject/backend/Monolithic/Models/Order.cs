namespace TFLPortal.Models;

public class Orderlist
{
    public int id { get; set; }

    public DateTime OrderDate { get; set; }
    public double OrderTotal { get; set; }
    public string OrderStatus { get; set; } // Nullable since it's marked as YES in the database
    public string PaymentMethod { get; set; }
    public string Username { get; set; }







}
