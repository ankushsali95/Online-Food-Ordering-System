namespace TFLPortal.Models;

public class OrderItemModel
{

    public int OrderItemId { get; set; }
    public String ProductName { get; set; }
    public int Quantity { get; set; }
    public double Price { get; set; }
}
