namespace TFLPortal.Models;

public class OrderModel
{

    public int OrderId { get; set; }
    public DateTime OrderDate { get; set; }
    public int OrderStatus { get; set; }
    public double OrderTotal { get; set; }
    public int PaymentMethod { get; set; }
    public String Username { get; set; }
    public List<OrderItemModel> OrderItems { get; set; }


}
