namespace TFLPortal.Models;

public class Order
{

    public int OrderId { get; set; }
    public DateTime OrderDate { get; set; }
    public int OrderStatus { get; set; }
    public double OrderTotal { get; set; }
    public int PaymentMethod { get; set; }
    public int UserId { get; set; }
    public List<OrderItem> OrderItems { get; set; }

    public static implicit operator Order(OrderModel v)
    {
        throw new NotImplementedException();
    }
}
