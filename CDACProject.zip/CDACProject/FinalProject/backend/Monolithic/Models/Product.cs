namespace TFLPortal.Models;

public class Product
{
    
    public int Id { get; set; }
    public String ProductName { get; set; }

    public int ProductType { get; set; }

    public Double ProductPrice { get; set; }

    public String ProductDesc { get; set; }
    public String Image { get; set; }


    //new changes
    public static implicit operator bool(Product v)
    {
        throw new NotImplementedException();
    }
}
