namespace TFLPortal.Models;

public class RevenueData
{

    public int Id { get; set; }
    public int Revenue { get; set; }
    public int MonthlyRevenue { get; set; }
    public int OrderCount { get; set; }
    public int MonthlyOrderCount { get; set; }




}
