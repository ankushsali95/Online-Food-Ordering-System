namespace TFLPortal.Models;

public class User
{
    //`id`, `username`, `email`, `password_hash`, `first_name`, `last_name`, `mobile_no`, `address`, `pincode`, `date_of_birth`, `gender`, `created_at`, `updated_at`, `status`, `last_login_at`, `role_id`
    public int Id { get; set; }
    public String Username { get; set; }
    public String Email { get; set; }

    public String Password { get; set; }

    public String First_name { get; set; }
    public String Last_name { get; set; }
    public String Mobile_no { get; set; }
    public String Address { get; set; }
    public int Pincode { get; set; }
    public DateTime Date_of_birth { get; set; }
    public String Gender { get; set; }

    public DateTime Created_at { get; set; }

    public DateTime Updated_at { get; set; }

    public String Status { get; set; }

    public DateTime Last_login_at { get; set; }

    public int Role_id { get; set;}
     

}
