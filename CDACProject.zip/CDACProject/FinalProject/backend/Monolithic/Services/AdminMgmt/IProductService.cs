using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
//using TFLPortal.Responses;


namespace TFLPortal.Services.AdminMgmt;

public interface IProductService
{
    Task<List<Product>> GetAllProducts();
   
    Task<bool> AddProduct(Product product);

    Task<bool> EditProduct(Product product);


   Task<bool> DeleteProduct(int id);

    
}
