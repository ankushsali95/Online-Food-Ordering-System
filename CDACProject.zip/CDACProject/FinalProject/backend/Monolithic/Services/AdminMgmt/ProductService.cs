using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;


namespace TFLPortal.Services.AdminMgmt;

public class ProductService : IProductService
{
    private readonly IConfiguration _configuration;
    private readonly string _connectionString;

    public ProductService(IConfiguration configuration)
    {
        _configuration = configuration;
        _connectionString =
            _configuration.GetConnectionString("DefaultConnection")
            ?? throw new ArgumentNullException("connectionString");
    }

    public async Task<List<Product>> GetAllProducts()
    {
        List<Product> products = new List<Product>();
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            string query =
              @"SELECT * from products";
            MySqlCommand command = new MySqlCommand(query, connection);
           

            
            await connection.OpenAsync();
            MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                Product product = new Product()
                {
                   

                    Id = reader.IsDBNull(reader.GetOrdinal("id")) ? 0 : reader.GetInt32(reader.GetOrdinal("id")),
                    ProductName = reader.IsDBNull(reader.GetOrdinal("product_name")) ? string.Empty : reader.GetString(reader.GetOrdinal("product_name")),
                    ProductType = reader.IsDBNull(reader.GetOrdinal("product_type")) ? 0 : reader.GetInt32(reader.GetOrdinal("product_type")),
                    ProductPrice = reader.IsDBNull(reader.GetOrdinal("product_price")) ?  0 : reader.GetDouble(reader.GetOrdinal("product_price")),
                    ProductDesc = reader.IsDBNull(reader.GetOrdinal("product_desc")) ? string.Empty : reader.GetString(reader.GetOrdinal("product_desc")),
                    Image = reader.IsDBNull(reader.GetOrdinal("image")) ? string.Empty : reader.GetString(reader.GetOrdinal("image")),
                   
                };
                products.Add(product);
            }
            await reader.CloseAsync();
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            await connection.CloseAsync();
        }
        return products;
    }


    public async Task<bool> AddProduct(Product product)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText =
                "Insert into products (id, product_name, product_type, product_price, product_desc, image) " +
                "values(@id, @product_name, @product_type, @product_price, @product_desc, @image)";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", product.Id);
            command.Parameters.AddWithValue("@product_name", product.ProductName);
            command.Parameters.AddWithValue("@product_type", product.ProductType);
            command.Parameters.AddWithValue("@product_price", product.ProductPrice);
            command.Parameters.AddWithValue("@product_desc", product.ProductDesc);
            command.Parameters.AddWithValue("@image", product.Image);
          
           
            

            int rowsAffected = await command.ExecuteNonQueryAsync(); // Execute the query asynchronously

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }


    public async Task<bool> EditProduct(Product product)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText =
                "UPDATE products " +
                "SET product_price = @product_price " +  // Added SET keyword
                "WHERE id = @id";                        // Removed the comma here
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", product.Id);
            command.Parameters.AddWithValue("@product_price", product.ProductPrice);

            int rowsAffected = await command.ExecuteNonQueryAsync(); // Execute the query asynchronously

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }

    public async Task<bool> DeleteProduct(int productId)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM products WHERE id = @id";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", productId);

            int rowsAffected = await command.ExecuteNonQueryAsync(); // Execute the query asynchronously

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }








}
