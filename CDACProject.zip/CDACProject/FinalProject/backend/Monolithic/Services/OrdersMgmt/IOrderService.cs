using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
//using TFLPortal.Responses;


namespace TFLPortal.Services.OrdersMgmt;

public interface IOrderService
{
    Task<List<Orderlist>> GetAllOrders();


    Task<RevenueData> singleRevenue();
    Task<OrderModel> GetSingleOrderWithItemsAsync(int oid);

    Task<bool> createOrder(Order order);
    Task<bool> AddOrderWithItems(Order order);

}
