using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace TFLPortal.Services.OrdersMgmt;

public class OrderService : IOrderService
{
    private readonly IConfiguration _configuration;
    private readonly string _connectionString;






    public OrderService(IConfiguration configuration)
    {
        _configuration = configuration;
        _connectionString =
            _configuration.GetConnectionString("DefaultConnection")
            ?? throw new ArgumentNullException("connectionString");
    }
    public async Task<List<Orderlist>> GetAllOrders()
    {
        List<Orderlist> orders = new List<Orderlist>();
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            string query =
              @"SELECT * from orderlist";
            MySqlCommand command = new MySqlCommand(query, connection);

            await connection.OpenAsync();
            MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                Orderlist order = new Orderlist()
                {
                    id = reader.GetInt32(reader.GetOrdinal("id")),
                    OrderDate = reader.GetDateTime(reader.GetOrdinal("order_date")),
                    OrderTotal = reader.GetDouble(reader.GetOrdinal("order_total")),
                    OrderStatus = reader.IsDBNull(reader.GetOrdinal("order_status")) ? null : reader.GetString(reader.GetOrdinal("order_status")),
                    PaymentMethod = reader.GetString(reader.GetOrdinal("payment_method")),
                    Username = reader.IsDBNull(reader.GetOrdinal("username")) ? null : reader.GetString(reader.GetOrdinal("username"))
                };
                orders.Add(order);
            }
            await reader.CloseAsync();
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            await connection.CloseAsync();
        }
        return orders;
    }


    public async Task<OrderModel> GetSingleOrderWithItemsAsync(int orderId)
    {
        OrderModel order = null;
        string connectionString = _connectionString;

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = @"
        SELECT o.id AS orderId, ol.order_date AS orderDate, ol.order_total AS orderTotal, 
               ol.order_status AS orderStatus, ol.payment_method AS paymentMethod,
               i.quantity, i.price, pd.product_name AS productName, u.username
        FROM orders o
        INNER JOIN order_items i ON o.id = i.order_id
        LEFT JOIN orderlist ol ON ol.id = o.id
        LEFT JOIN products pd ON pd.id = i.product_id
        LEFT JOIN users u ON u.id = o.user_id
        WHERE o.id = @OrderId;";

            try
            {
                await connection.OpenAsync();

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderId", orderId);

                    using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            order = new OrderModel
                            {
                                OrderId = reader.GetInt32(reader.GetOrdinal("orderId")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("orderDate")),
                                Username = reader.GetString("username"),
                                OrderTotal = reader.GetDouble(reader.GetOrdinal("orderTotal")),
                                OrderItems = new List<OrderItemModel>()
                            };

                            do
                            {
                                OrderItemModel item = new OrderItemModel
                                {
                                    Quantity = reader.GetInt32(reader.GetOrdinal("quantity")),
                                    Price = reader.GetDouble(reader.GetOrdinal("price")),
                                    ProductName = reader.GetString("productName"),

                                };
                                order.OrderItems.Add(item);
                            } while (await reader.ReadAsync());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error retrieving single order with items: " + ex.Message);
                throw;
            }
        }

        return order;
    }


    public async Task<RevenueData> singleRevenue()
    {

        RevenueData result = null;
        using (MySqlConnection connection = new MySqlConnection(_connectionString))
        {
            try
            {
                await connection.OpenAsync();

                MySqlCommand command = new MySqlCommand(
                    "SELECT * FROM revenue_view WHERE id = @id",
                    connection);
                command.Parameters.AddWithValue("@id", 1); // Assuming you want to fetch the record with Id = 1

                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        result = new RevenueData
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("id")),
                            Revenue = reader.GetInt32(reader.GetOrdinal("revenue")),
                            MonthlyRevenue = reader.GetInt32(reader.GetOrdinal("mrevenue")),
                            OrderCount = reader.GetInt32(reader.GetOrdinal("ordercount")),
                            MonthlyOrderCount = reader.GetInt32(reader.GetOrdinal("mordercount"))
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., log the error)
                Console.WriteLine($"Error fetching revenue data: {ex.Message}");
            }
        }

        return result;
    }


    public async Task<bool> createOrder(Order order)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText =
                "INSERT INTO orders (id, order_date, order_status, order_total, payment_method, user_id) " +
                "VALUES (@OrderId, now(),@OrderStatus, @OrderTotal, @payment_method, @UserId)";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@OrderId", order.OrderId);
            command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
            command.Parameters.AddWithValue("@OrderStatus", order.OrderStatus);
            command.Parameters.AddWithValue("@OrderTotal", order.OrderTotal);
            command.Parameters.AddWithValue("@payment_method", order.PaymentMethod);
            command.Parameters.AddWithValue("@UserId", order.UserId);

            int rowsAffected = await command.ExecuteNonQueryAsync();

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }

    public async Task<bool> AddOrderWithItems(Order order)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        MySqlTransaction transaction = null;
        try
        {
            await connection.OpenAsync();
            transaction = await connection.BeginTransactionAsync();

            MySqlCommand orderCommand = new MySqlCommand();
            orderCommand.CommandText =
                "INSERT INTO orders (order_date, order_status, order_total, payment_method, user_id) " +
                "VALUES (now(), @OrderStatus, @OrderTotal, @payment_method, @UserId)";
            orderCommand.Connection = connection;
            orderCommand.Transaction = transaction;
            orderCommand.Parameters.AddWithValue("@OrderDate", order.OrderDate);
            orderCommand.Parameters.AddWithValue("@OrderStatus", order.OrderStatus);
            orderCommand.Parameters.AddWithValue("@OrderTotal", order.OrderTotal);
            orderCommand.Parameters.AddWithValue("@payment_method", order.PaymentMethod);
            orderCommand.Parameters.AddWithValue("@UserId", order.UserId);

            await orderCommand.ExecuteNonQueryAsync();
            int orderId = (int)orderCommand.LastInsertedId;

            foreach (var orderItem in order.OrderItems)
            {
                MySqlCommand itemCommand = new MySqlCommand();
                itemCommand.CommandText =
                    "INSERT INTO order_items (order_id, product_id, quantity, price) " +
                    "VALUES (@OrderId, @ProductId, @Quantity, @Price)";
                itemCommand.Connection = connection;
                itemCommand.Transaction = transaction;
                itemCommand.Parameters.AddWithValue("@OrderId", orderId);
                itemCommand.Parameters.AddWithValue("@ProductId", orderItem.ProductId);
                itemCommand.Parameters.AddWithValue("@Quantity", orderItem.Quantity);
                itemCommand.Parameters.AddWithValue("@Price", orderItem.Price);

                await itemCommand.ExecuteNonQueryAsync();
            }

            await transaction.CommitAsync();
            status = true;
        }
        catch (Exception ee)
        {
            if (transaction != null)
            {
                await transaction.RollbackAsync();
            }
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }


}
