-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: onlinefooddelivery
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` int NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `discount_per` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_delivery`
--

DROP TABLE IF EXISTS `order_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `delivery_status` int NOT NULL,
  `order_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_delivery`
--

LOCK TABLES `order_delivery` WRITE;
/*!40000 ALTER TABLE `order_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` double NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,1,77.56,2),(2,1,1,1000,1),(3,2,4,4000,1),(4,2,3,36,3),(5,2,3,297.75,4),(6,2,2,198.38,7),(7,3,1,77.56,2),(8,3,1,12,3),(9,4,1,77.56,2),(10,4,1,12,3),(11,4,1,99.25,4),(12,5,1,77.56,2),(13,5,1,12,3),(14,6,1,100,1),(15,6,1,100,1),(16,7,3,300,1),(17,7,4,600,16),(18,8,4,400,1),(19,8,3,297.75,4),(20,9,1,77.56,2),(21,9,1,100,1),(22,10,1,77.56,2),(23,10,1,100,1),(24,11,1,100,1),(25,11,1,100,1),(26,12,1,77.56,2),(27,13,1,100,1),(28,13,1,150,16),(29,14,1,300,7),(30,14,2,200,1),(31,14,1,140,19);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `orderlist`
--

DROP TABLE IF EXISTS `orderlist`;
/*!50001 DROP VIEW IF EXISTS `orderlist`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `orderlist` AS SELECT 
 1 AS `id`,
 1 AS `order_date`,
 1 AS `order_total`,
 1 AS `order_status`,
 1 AS `payment_method`,
 1 AS `username`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `order_date` datetime NOT NULL,
  `order_total` double NOT NULL,
  `order_status` int NOT NULL,
  `payment_method` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,27,'2024-02-19 02:02:10',1077.56,1,1),(2,30,'2024-02-19 06:56:33',4532.13,1,1),(3,12,'2024-02-19 13:29:33',89.56,1,1),(4,12,'2024-02-19 17:18:15',188.81,1,1),(5,12,'2024-02-19 19:06:16',89.56,1,1),(6,12,'2024-02-19 19:09:45',200,1,1),(7,12,'2024-02-19 20:40:09',900,1,1),(8,12,'2024-02-20 09:01:16',697.75,1,1),(9,33,'2024-02-21 06:48:45',177.56,1,1),(10,12,'2024-02-21 19:28:20',177.56,1,1),(11,12,'2024-02-21 22:40:09',200,1,1),(12,12,'2024-02-21 22:46:40',77.56,1,1),(13,34,'2024-02-21 22:52:18',250,1,1),(14,35,'2024-02-21 23:22:16',640,1,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `transaction_id` varchar(45) NOT NULL,
  `transaction_status` int NOT NULL,
  `user_id` int NOT NULL,
  `coupon_id` int NOT NULL,
  `Amount` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id_UNIQUE` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission_id` bigint unsigned NOT NULL,
  `permission_name` varchar(255) NOT NULL,
  PRIMARY KEY (`permission_id`),
  UNIQUE KEY `permission_name` (`permission_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (4,'all'),(1,'create'),(3,'delete'),(2,'update');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(45) NOT NULL,
  `product_type` int NOT NULL COMMENT 'will use 0-veg , 1-non veg',
  `image` varchar(150) NOT NULL,
  `product_price` double NOT NULL,
  `product_desc` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Crispy Chicken',1,'https://cdn.pixabay.com/photo/2019/01/29/18/05/burger-3962996_1280.jpg',100,'Chicken breast, chilli sauce, tomatoes, pickles, coleslaw'),(2,'Ultimate Bacon',1,'https://cdn.pixabay.com/photo/2012/03/01/00/25/bacon-19573_1280.jpg',77.56,'House patty, cheddar cheese, bacon, onion, mustard'),(3,'Black Sheep',0,'https://cdn.pixabay.com/photo/2014/10/23/18/05/burger-500054_640.jpg',220,'American cheese, tomato relish, avocado, lettuce, red onion'),(5,'Double Burger',0,'https://cdn.pixabay.com/photo/2015/07/30/18/23/burger-868145_640.jpg',59.25,'2 patties, cheddar cheese, mustard, pickles, tomatoes'),(6,'Turkey Burger',1,'https://cdn.pixabay.com/photo/2016/05/25/10/43/hamburger-1414422_640.jpg',79.18,'Turkey, cheddar cheese, onion, lettuce, tomatoes, pickles'),(7,'Smokey House',0,'https://cdn.pixabay.com/photo/2022/05/25/21/28/burger-7221436_640.jpg',300,'patty, cheddar cheese, onion, lettuce, tomatoes, pickles'),(8,'Classic Burger',1,'https://cdn.pixabay.com/photo/2017/11/12/21/11/hamburger-2943825_640.jpg',89.12,'cheddar cheese, ketchup, mustard, pickles, onion'),(16,'Spicy burger',1,'https://cdn.pixabay.com/photo/2020/12/16/07/05/hamburger-5835823_960_720.jpg',150,'spicy chilly burger'),(17,'veg burger',0,'https://cdn.pixabay.com/photo/2018/05/30/19/18/burger-3442227_1280.jpg',130,'cheesy burger'),(18,'Vegan burger',0,'https://cdn.pixabay.com/photo/2014/10/19/20/59/hamburger-494706_1280.jpg',180,'Vegan burger, with fresh veggies'),(19,'Indo burger',1,'https://cdn.pixabay.com/photo/2019/01/21/12/47/burger-3946012_1280.jpg',140,'with taste of indian spices');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `revenue_view`
--

DROP TABLE IF EXISTS `revenue_view`;
/*!50001 DROP VIEW IF EXISTS `revenue_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `revenue_view` AS SELECT 
 1 AS `id`,
 1 AS `revenue`,
 1 AS `mrevenue`,
 1 AS `ordercount`,
 1 AS `mordercount`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` bigint unsigned NOT NULL,
  `role_name` varchar(255) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Admin'),(2,'Customer'),(3,'Delivery person');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `permission_type` varchar(45) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,4,'Product'),(2,4,'Order');
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `session_id` varchar(255) NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `session_data` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('sessionId123',1,'{\"attribute1\": \"value1\", \"attribute2\": \"value2\"}','2024-01-07 22:46:41','2024-01-03 00:00:00');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `pincode` int NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive','Suspended') DEFAULT 'Active',
  `last_login_at` datetime DEFAULT NULL,
  `role_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_no_UNIQUE` (`mobile_no`),
  KEY `role_fk_idx` (`role_id`),
  CONSTRAINT `role_fk` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12,'akash@gmail.com','akash@gmail.com','$2a$11$hEFh7bEO2FVlgu4W/PKcf./pv2jWAZmetnqO3MqDBFpF.LMFKfKXC','Akash','Pawar','776997429','Dattanagar',411046,'2024-02-17','Male','2024-02-17 18:00:11','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(18,'admin@gmail.com','admin@gmail.com','$2a$11$0DBRcaMfDI0RpCsBUYAn6.7ccQBL4WnHvHWJUiwSik2xi.4M2G5OW','Admin','Admin','9890004288','address',411046,'2024-02-17','Male','2024-02-17 18:00:11','2024-02-18 02:25:47','Active','2024-02-17 18:00:11',1),(26,'new@gmail.com','new@gmail.com','$2a$11$17P10yLHlXkk3ztWYWQdNO/4T1fsbXEE9wTYPJfB7inZSRy29WB4G','New','user','9897676756','new',422434,'2024-02-17','Male','2024-02-17 18:00:11','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(27,'stark@gmail.com','stark@gmail.com','$2a$11$fuXEwNDq1Y8PGXTTHtDNdOPANWkrBoFoDuSER44auQ38prZTvIg3q','Tony ','stark','6756456365','katraj',411232,'2024-02-17','Male','2024-02-17 18:00:11','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(28,'arvind@gmail.com','arvind@gmail.com','$2a$11$dW.EQoEPY9lptS2H64yVzu5gyLF93dqZenVaR65d8p8kZSR1kPY/G','Arvind','Pawar','4366547547','23432',431414,'2024-02-17','Male','2024-02-17 18:00:11','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(29,'arvind@gmail.com','arvind@gmail.com','$2a$11$zbJEaA9PYGvravzWiMLxBeaOQfllBAdps.jsnAcDVZP0mgFL7oURi','Arvind','Pawar','436653','sfdg',431414,'2024-02-17','Male','2024-02-19 03:35:58','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(30,'neha@gmail.com','neha@gmail.com','$2a$11$wzAOoGHmqlTsGXMbu5okwO39lZzkGJU/3lT8QwLWe31b385Gv.9oW','Neha','Mane','2432543546','dfdgfdg',112323,'2024-02-17','Male','2024-02-19 06:52:10','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(31,'aka@gmail.com','aka@gmail.com','$2a$11$4U5hL69vBa36kV10JUDOaudknDubWJOinLjlKSy5mwltanM24SiSG','hee','dfg','6577452345','fgfh',354545,'2024-02-17','Male','2024-02-19 14:40:09','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(32,'new@gmail.com','new@gmail.com','$2a$11$2HG2OmT2NjY3sEKJ1Vq2/eXvYE.qTCwpRxRe5EYj5GTAWEKikdDCW','new ','user','7685735457','fgfh',354545,'2024-02-17','Male','2024-02-20 08:59:22','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(33,'meena@gmail.com','meena@gmail.com','$2a$11$i1yaPHPZzI7cPS9ak8v0nuvd0vKSPoSKZp.0.jM0NhFY7FcuR1Y.2','Meena','Kare','2323232323','pune',121212,'2024-02-17','Male','2024-02-21 06:21:47','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(34,'gita@gmail.com','gita@gmail.com','$2a$11$Q3jp2PIokyx92zAfK7zxwun5wZ8m/Tf35QXj2thGXhuotTsQC5ww2','Gita','Kale','1111111111','katraj',555555,'2024-02-17','Male','2024-02-21 22:50:28','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2),(35,'viju@gmail.com','viju@gmail.com','$2a$11$j8A8aNNv4dXXqRvJkU16Gehl0XUhQc8GJnusxS91f79nfB7P08xW2','Vijaya','Ubale','8978966756','Hinjawadi',411000,'2024-02-17','Male','2024-02-21 23:16:08','2024-02-17 18:00:11','Active','2024-02-17 18:00:11',2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `orderlist`
--

/*!50001 DROP VIEW IF EXISTS `orderlist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orderlist` AS select `orders`.`id` AS `id`,`orders`.`order_date` AS `order_date`,`orders`.`order_total` AS `order_total`,(case when (`orders`.`order_status` = 1) then 'In Progress' when (`orders`.`order_status` = 2) then 'Completed' end) AS `order_status`,'Online' AS `payment_method`,`users`.`username` AS `username` from (`orders` left join `users` on((`users`.`id` = `orders`.`user_id`))) order by `orders`.`order_date` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `revenue_view`
--

/*!50001 DROP VIEW IF EXISTS `revenue_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `revenue_view` AS select 1 AS `id`,`overallrevenue`() AS `revenue`,`monthrevenue`() AS `mrevenue`,`ordercount`() AS `ordercount`,`ordermonthcount`() AS `mordercount` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-21 23:28:01
