import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home/Home";
import Signup from "./components/Layouts/Signup";
import Signin from "./components/Layouts/Signin";
import Menu from "./pages/Home/Menu";
import Cart from "./components/Layouts/Cart";
import FrontPage from "./pages/Home/Home";
import AdminPage from "./pages/Home/AdminPage";
//import cartSlice from "../../features/cartSlice";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';import 'admin-lte/dist/css/adminlte.min.css';
import 'admin-lte/plugins/fontawesome-free/css/all.min.css';
import 'admin-lte/plugins/overlayScrollbars/css/OverlayScrollbars.min.css';
import 'admin-lte/plugins/icheck-bootstrap/icheck-bootstrap.min.css';
import 'admin-lte/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js';
import 'admin-lte/dist/js/adminlte.min.js';







//import Orders from "./components/Layouts/Orders";
//import Cart from "./components/Layouts/Cart";


import Contact from './pages/Home/Contact';
import ProductForm from "./components/Layouts/ProductForm";
import AdminDashboardPage from "./pages/Home/AdminDashboardPage";
import ProductPage from "./pages/Home/ProductPage";
import DeliveryPage from "./pages/Home/DeliveryPage";
import OrderPage from "./pages/Home/OrderPage";
import OrdersPage from "./pages/Home/OrdersPage";
//import Orders from "./pages/Home/Ordersdetails";
import Orders from "./components/Layouts/Orders";
import Ordersdetails from "./pages/Home/Ordersdetails";
import Allordersdetails from "./pages/Home/Allordersdetails";

function App() {
  return (
    <div className="container-fluid">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/Signin" element={<Signin />} />
        <Route path="/Contact" element={<Contact />} />
        <Route path="/Menu" element={<Menu />} />
        <Route path="/Cart" element={<Cart />} />
        <Route path="/cartSlice" element={<cartSlice />} />
        <Route path="/FrontPage" element={<FrontPage />} />
        <Route path="/AdminPage" element={<AdminPage />} />
        <Route path="/ProductForm" element={<ProductForm />} />
        <Route path="/AdminDashboardPage" element={<AdminDashboardPage />} />
        <Route path="/OrderPage" element={<OrderPage />} />
        <Route path="/ProductPage" element={<ProductPage />} />
        <Route path="/DeliveryPage" element={<DeliveryPage />} />
        <Route path="/Ordersdetails" element={<Ordersdetails/>} />
        <Route path="/orderadmin/:orderId" element={<Allordersdetails/>} />
        <Route path="/order/:orderId" element={<Ordersdetails/>} />
        {/* <Route path="/OrdersPage" element={<OrdersPage />} /> */}
        <Route path="/Orders" element={<Orders />} />
        


        {/* <Route path="/Orders" element={<Orders />} />
        <Route path="/Cart" element={<Cart />} /> */}

      </Routes>
    <ToastContainer />
    </div>
  );
}

export default App;
