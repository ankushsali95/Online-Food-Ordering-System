

import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from "react-router-dom";

const AdminHeader = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    const isConfirmed = window.confirm("Are you sure you want to log out?");
    if (isConfirmed) {
      sessionStorage.removeItem('token');
      navigate('/');
    }
  }

  return (
    <nav className="main-header navbar navbar-expand navbar-white navbar-light">
      {/* Left navbar links */}
      <ul className="navbar-nav">
        <li className="nav-item">
          <a className="nav-link" data-widget="pushmenu" href="#" role="button"><i className="fas fa-bars"></i></a>
        </li>
        <li className="nav-item d-none d-sm-inline-block">
          <a href="/" className="nav-link">Home</a>
        </li>
      </ul>

      {/* Right navbar links */}
      <ul className="navbar-nav ml-auto">
        <li className="nav-item">
          <a className="nav-link" href="#">
            {sessionStorage.token && (
              <i style={{ cursor: 'pointer' }} onClick={handleClick}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="feather feather-log-out">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7">
                  </polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>Logout
              </i>
            )}
          </a>
        </li>
      </ul>
    </nav>
  );
};

export default AdminHeader;


