import React from 'react';
import ProductForm from './ProductForm';
import { Link } from 'react-router-dom';

const AdminSidebar = () => {
  return (
    <aside className="main-sidebar sidebar-dark-primary elevation-4">
      {/* Brand Logo */}
      <span className="brand-link">
        <span className="brand-text font-weight-light">Admin Panel</span>
      </span>

      {/* Sidebar */}
      <div className="sidebar">
        {/* Sidebar Menu */}
        <nav className="mt-2">
          <ul className="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li className="nav-item">
              <Link  to="/AdminDashboardPage" className="nav-link">
                <i className="nav-icon fas fa-tachometer-alt"></i>
                <p>Dashboard</p>
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/OrderPage" className="nav-link">
                <i className="nav-icon fas fa-file-invoice"></i>
                <p>Orders</p>
              </Link>
              {/* Dropdown for Order Details */}
              {/* <ul className="nav nav-treeview">
                <li className="nav-item">
                  <Link href="/order/details" className="nav-link">
                    <i className="nav-icon far fa-circle"></i>
                    <p>Order Details</p>
                  </Link>
                </li>
              </ul> */}
            </li>

            <li className="nav-item">
              <Link to="/ProductPage" className="nav-link">
                <i className="nav-icon fas fa-box"></i>
                <p>Products</p>
              </Link>
            </li>
            
            <li className="nav-item">
              <Link to="/DeliveryPage" className="nav-link">
                <i className="nav-icon fas fa-truck"></i>
                <p>Delivery Persons</p>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  );
};

export default AdminSidebar;
