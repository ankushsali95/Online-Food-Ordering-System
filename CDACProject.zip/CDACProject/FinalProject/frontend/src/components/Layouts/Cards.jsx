import React from "react";
import { Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import { clear, updateQuantity ,addItem} from '../../features/cartSlice';
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { toast } from 'react-toastify'
import { placeOrder } from '../../services/order'






function Cards({ cid, image, rating, title, paragraph, price, renderRatingIcons }) {
  const [total, setTotal] = useState(0)

  // use it for updating the cart slice
  const dispatch = useDispatch()



  const addItemToCart = () => {
    console.log("inside addto cart");
    dispatch(addItem({ ...{id: cid, name:title,price:price, image:image}, quantity: 1 }))
  }

  // reading the current state
  const cart = useSelector((state) => state.cart)
  useEffect(() => {
    let totalAmount = 0
    for (const item of cart.items) {
      totalAmount += item['price'] * item['quantity']
    }
    setTotal(totalAmount)
  }, [cart.items])

  const onQuantityUpdate = (itemId, quantity) => {
    dispatch(updateQuantity({ itemId, quantity }))
  }

  const onPlaceOrder = async () => {
    const result = await placeOrder(cart.items, total)
    if (result['status'] == 'success') {
      dispatch(clear())
      toast.success('successfully placed an order')
    } else {
      toast.error(result['error'])
    }
  }




  return (
    <Col sm={6} lg={4} xl={3} className="mb-4">
      <Card className="overflow-hidden">
        <div className="overflow-hidden">
          <Card.Img variant="top" src={image} />
        </div>
        <Card.Body>
          <div className="d-flex align-items-center justify-content-between">
            {/* <div className="item_rating">{renderRatingIcons(rating)}</div>
            <div className="wishlist">
              <i class="bi bi-heart"></i>
            </div> */}
          </div>


          

          <Card.Title>{title}</Card.Title>
          <Card.Text>{paragraph}</Card.Text>

          <div className="d-flex align-items-center justify-content-between">
            <div className="menu_price">
              <h5 className="mb-0">Rs {price}</h5>
            </div>
            <div className="add_to_card">
              <a className="cursorpointer" onClick={addItemToCart}>
                <i class="bi bi-bag me-2"></i>

                Add To Cart
              </a>
            </div>
          </div>
        </Card.Body>
      </Card>
    </Col>
  );
}

export default Cards;



// import { useState } from 'react';
// import { Link } from 'react-router-dom';
// import { Col, Card } from 'react-bootstrap';

// function Cards({ image, title, paragraph, price }) {
//   // Define state to manage the cart items
//   const [cartItems, setCartItems] = useState([]);

//   // Function to handle adding an item to the cart
//   const addToCart = () => {
//     // Create a new item object representing the card
//     const newItem = { image, title, paragraph, price };

//     // Add the new item to the cartItems array
//     setCartItems([...cartItems, newItem]);
//   };

//   return (
//     <Col sm={6} lg={4} xl={3} className="mb-4">
//       <Card className="overflow-hidden">
//         <div className="overflow-hidden">
//           <Card.Img variant="top" src={image} />
//         </div>
//         <Card.Body>
//           <Card.Title>{title}</Card.Title>
//           <Card.Text>{paragraph}</Card.Text>

//           <div className="d-flex align-items-center justify-content-between">
//             <div className="menu_price">
//               <h5 className="mb-0">Rs {price}</h5>
//             </div>
//             <div className="add_to_cart">
//               {/* Add to Cart button with onClick handler */}
//               <button onClick={addToCart} className="btn btn-primary">
//                 <i className="bi bi-bag me-2"></i>
//                 Add To Cart
//               </button>
//             </div>
//           </div>
//         </Card.Body>
//       </Card>
//     </Col>
//   );
// }

// export default Cards;

