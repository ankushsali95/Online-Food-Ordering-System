import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { toast } from 'react-toastify'
import Header from '../Layouts/Header';
import cartSlice from '../../features/cartSlice';
import config from '../../config'
import { clear, updateQuantity } from '../../features/cartSlice'
import { placeOrder } from '../../services/order'
import { Link } from 'react-router-dom'
import axios from 'axios';
import Ordersdetails from '../../pages/Home/Ordersdetails';


export function Cart() {
  const [total, setTotal] = useState(0)

  // use it for updating the cart slice
  const dispatch = useDispatch()

  // reading the current state
  const cart = useSelector((state) => state.cart)
  useEffect(() => {
    let totalAmount = 0
    for (const item of cart.items) {
      totalAmount += item['price'] * item['quantity']
    }
    setTotal(totalAmount)
  }, [cart.items])

  const onQuantityUpdate = (itemId, quantity) => {
    dispatch(updateQuantity({ itemId, quantity }))
  }

  function loadScript(src) {
    return new Promise((resolve) => {
        const script = document.createElement("script");
        script.src = src;
        script.onload = () => {
            resolve(true);
        };
        script.onerror = () => {
            resolve(false);
        };
        document.body.appendChild(script);
    });
}
  const onPlaceOrder = async () => {
   

    const res = await loadScript(
      "https://checkout.razorpay.com/v1/checkout.js"
  );

  if (!res) {
      alert("Razorpay SDK failed to load. Are you online?");
      return;
  }

  // creating a new order
  // const result = await axios.post("http://localhost:5000/payment/orders");

  // if (!result) {
  //     alert("Server error. Are you online?");
  //     return;
  // }

  // Getting the order details back


  const options = {
      key: "rzp_test_6QcfFPZ3PRa0Q7", // Enter the Key ID generated from the Dashboard
      amount: (parseInt(total*1.05)*100).toString(),
      currency: 'INR',
      name: "Hungry Buddy",
      description: "Test Transaction",
      image: null,
      handler: async function (response) {
          const data = {
              // orderCreationId: order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              // razorpayOrderId: response.razorpay_order_id,
              // razorpaySignature: response.razorpay_signature,


          };

          const result = await placeOrder(cart.items, total)
          dispatch(clear())
          toast.success('successfully placed an order')
          // const result = await axios.post("http://localhost:5000/payment/success", data);

          // alert(result.data.msg);
      },
      prefill: {
          name: "",
          email: "",
          contact: "",
      },
      notes: {
          address: "",
      },
      theme: {
          color: "#61dafb",
      },
  };

  const paymentObject = new window.Razorpay(options);
  paymentObject.open();
  }

  return (
    <>
      <Header/>

      <div className='container'>
        <h1 className='title'>Cart</h1>




        {/* conditional rendering */}
        {cart.items.length == 0 && (
          <h5 style={{ textAlign: 'center' }}><br/><br/>
            There are no burgers in your cart! It seems like you are now
            following the healthy habits!!<br/><br/>
            <img src="https://cdn.pixabay.com/photo/2012/04/13/01/51/hamburger-31775_640.png" alt="Hamburger" style={{ width: "80px", height: "80px" }} />
          </h5>
        )}
        {cart.items.length > 0 && (
          <div>
            <table className='table table-striped'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {cart.items.map((item, index) => {
                  return (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td>
                        <img
                          style={{ width: 50 }}
                          src={item['image']}
                          alt=''
                        />
                      </td>
                      <td>{item['name']}  </td>
                      <td>{item['price'].toFixed(2)}</td>
                      <td>{item['quantity']}</td>
                      <td>{(item['price'] * item['quantity']).toFixed(2)}</td>
                      <td>
                        <button
                          onClick={() => {
                            onQuantityUpdate(item['id'], item['quantity'] + 1)
                          }}
                          className='btn btn-success btn-sm'
                        >
                          +
                        </button>
                        <button
                          onClick={() => {
                            onQuantityUpdate(item['id'], item['quantity'] - 1)
                          }}
                          className='btn btn-success btn-sm ms-1'
                        >
                          -
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan='5' style={{ textAlign: 'right' }}>
                    Total Amount (Including Tax)
                  </td>
                  <td>{(total*1.05).toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>

            <div className="text-center">
  <Link onClick={onPlaceOrder} className='btn btn-info mr-2'>
    Place Order
  </Link>
  
</div>
          </div>
        )}
      </div>
    </>
  )
}

export default Cart
