import React, { useState, useEffect } from "react";
import { Container, Nav, NavLink, Navbar } from "react-bootstrap";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Logo from "../../assets/logo/logo.png";
import "../../styles/HeaderStyle.css";
import { useSelector } from 'react-redux'
import ProfileDropdown from "../../components/Layouts/Profiledropdown";





const Header = () => {
  const [nav, setNav] = useState(false);
    // Update the document   });
    const [value, setValue] = useState(null);

    //new addition for dropdown
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
   
   
   
   
   
    const location =useLocation();

    useEffect(() => { console.log("hello")
  setValue(localStorage.getItem('email'));
  }) 

  // Scroll Navbar
  const changeValueOnScroll = () => {
    const scrollValue = document?.documentElement?.scrollTop;
    scrollValue > 100 ? setNav(true) : setNav(false);
  };

  const navigate = useNavigate();
// const handleClick =() =>{ 
//   sessionStorage.removeItem('token');
//   navigate('/');
    
// }


//dropdown menu
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    // Add your logout logic here
  };




const handleClick = () => {
  const isConfirmed = window.confirm("Are you sure you want to log out?");
  if (isConfirmed) {
    sessionStorage.removeItem('token');
    navigate('/');
  }
}

const cart = useSelector((state) => state.cart)


  window.addEventListener("scroll", changeValueOnScroll);

//function to check if current page is cart page

const isCartPage = location.pathname==='/Cart';

  return (
    <header>
      <Navbar
        collapseOnSelect
        expand="lg"
        className={`${nav === true ? "sticky" : ""}`}
      >
        <Container>
          <Navbar.Brand href="#home">
            <Link to="/" className="logo">
              <img src={Logo} alt="Logo" className="img-fluid" />
            </Link>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav"  >
            <Nav className="ms-auto" >
              <Nav.Link as={Link} to="/"   >
                Home
              </Nav.Link>
              
              <Nav.Link as={Link} to={ sessionStorage.token ? "/Menu": "/Signin"}>
                Our Menu
              </Nav.Link>
              
              <Nav.Link as={Link} to="/Contact">
                Contact
              </Nav.Link>
              { !sessionStorage.token  && (<Nav.Link as={Link} to="/Signin">
                Login
              </Nav.Link>)}
            

            <Nav.Link as={Link} to ="/Cart">
              <Link className='nav-link' aria-current='page' to='/Cart'>
                Cart ({cart.items.length})
              </Link>
            </Nav.Link>

            {/* <Nav.Link as={Link} to ="/Cart">
              <Link className='nav-link' aria-current='page' to='/Cart'>
                Orders ({cart.items.length})
              </Link>
            </Nav.Link> */}


            { sessionStorage.token  && (
            <Link className='nav-link' aria-current='page' to='/Orders'>
                Orders 
              </Link>
              )}
              {/* {<Nav.Link as={Link} to="/">

              <Link className='nav-link' aria-current='page' to='/Cart'>
              
                <div className="cart">
                  <i class="bi bi-bag fs-5"></i>
                  <em className="roundpoint">2</em>
                </div>


              </Link>
               
              </Nav.Link>         
              } */}
             
             {/* <li className="nav-item profile-icon" onClick={toggleDropdown}>
            <i className="bi bi-person"></i>
            {isDropdownOpen && (
              <ul className="dropdown-menu">
                <li className="dropdown-item">
                  <Link to="/edit-profile">Edit Profile</Link>
                </li>
                <li className="dropdown-item">
                  <Link to="/orders">Orders</Link>
                </li>
                <li className="dropdown-item" onClick={handleLogout}>
                  Logout
                </li>
              </ul>
            )}
          </li> */}






              { sessionStorage.token  && (<><span >{sessionStorage.username}</span>
              <i style={{ cursor: 'pointer' }} onClick={handleClick} ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4">
                  </path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12">
                    </line></svg>Logout</i></>
              )}
              
              




            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </header>
  );
};

export default Header;
