import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getAllOrders } from '../../services/order'
import { Link } from 'react-router-dom';


const OrderTable = () => {
    const [orders, setOrders] = useState([])

    
  const loadOrders = async () => {
    const result = await getAllOrders()
    console.log(result);
    setOrders(result);
  }
    const tableStyle = {
        height: '55vh',
    overflowY: 'scroll',
      };

      useEffect(() => {
        loadOrders()
      }, [])
    
    
    return(
    <>
      
          {/* Home Section Hero Banner */}
     
         
  
  
          <div className=" p-4">
          <section className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1>Order List</h1>
              </div>
            </div>
          </div>
        </section>
  
        {/* Main content */}
        <section className="content">
          <div className="container-fluid">
            {/* Order list table */}
            <div className="row">
              <div className="col-12">
                <div className="card">
                  <div className="card-body"  style={tableStyle}>
                    <table className="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>Sr. No</th>
                          <th>Order Date</th>
                          <th>Customer Name</th>
                          <th>Payment Method</th>
                          <th>Total Amount(Inc. tax)</th>
                          <th>Order Status</th>
                          <th>Order Details</th>
                         
                        </tr>
                      </thead>
                      <tbody>
                        {orders.map((order, index) => (

                          <tr key={order.id}>
                            <td>{index+1}</td>
                            <td>{order.orderDate}</td>
                           
                            <td>{order.username}</td>
                            <td>{order.paymentMethod}</td>
                            <td>{(order.orderTotal * 1.05).toFixed(2)}</td>
                            <td>{order.orderStatus}</td>
                            <td>
                              {/* &nbsp;&nbsp;<button className="btn btn-secondary mr-2" onClick={handleUpdateProduct}>Update</button>&nbsp; */}
                              
                            <Link to={'/orderadmin/'+order.id} className='btn btn-success'>Details</Link>
                         </td> </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
  
  
   
          </div>
         
  
          
  
          
  
          {/* Home Section Contact */}
          
       
      </>
    );
  };
  
  export default OrderTable;
  