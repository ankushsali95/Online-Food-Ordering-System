import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
//import Navbar from '../components/Navbar'
import { getAllOrders } from '../../services/order'
//import Razorpay from 'razorpay';
import Header from './Header'
import Signin from '../Layouts/Signin';
import { Link } from 'react-router-dom';

//export function Orders() 
const Orders = () =>{
 


    const [orderslist, setOrders] = useState([])

    
  const loadOrders = async () => {
    const result = await getAllOrders()
    console.log(result);
    setOrders(result);
  }
    const tableStyle = {
        height: '55vh',
    overflowY: 'scroll',
      };

      useEffect(() => {
        loadOrders()
      }, [])
    
  return (
    <>
      <Header />
      <div className='container'>
        <h1 className='title'>Orders</h1>
        {/* {orders.length == 0 && (
          <h5 style={{ textAlign: 'center' }}>There are no orders</h5>
        )}

        {orders.length > 0 && (
          <table className='table table-striped'>
            <thead>
              <tr>
                <th>No</th>
                <th>Order No</th>
                <th>Date</th>
                <th>Total Amount</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, index) => {
                return (
                  <tr>
                    <td>{index + 1}</td>
                    <td>{order['id']}</td>
                    <td>{order['createdTimestamp']}</td>
                    <td>{order['totalAmount']}</td>
                    <td>
                      <button className='btn btn-success'>Details</button>
                      <button className='btn btn-danger ms-2'>Delete</button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table> */}



          <section className="content">
          <div className="container-fluid">
            {/* Order list table */}
            <div className="row">
              <div className="col-12">
                <div className="card">
                  <div className="card-body" >
                    <table className="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>OrderId</th>
                          <th>Order Date</th>
                          <th>Customer Name</th>
                          <th>Payment Method</th>
                          <th>Total Amount(Inc. tax)</th>
                          <th>Order Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orderslist.filter(order => order.username === sessionStorage.username).map((order, index) => (

                          <tr key={order.id}>
                            <td>{index+1}</td>
                            <td>{order.orderDate}</td>
                           
                            <td>{order.username}</td>
                            <td>{order.paymentMethod}</td>
                            <td>{(order.orderTotal * 1.05).toFixed(2)}</td>
                            <td>{order.orderStatus}</td>
                            <td>
                      <Link to={'/order/'+order.id}> <button className='btn btn-success'>Details</button></Link>
                      {/* <button className='btn btn-danger ms-2'>Delete</button> */}
                    </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>









        {/* )} */}
      </div>
    </>
  )
}

export default Orders
