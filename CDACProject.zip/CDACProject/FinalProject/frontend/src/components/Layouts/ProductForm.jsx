import React, { useState } from 'react';
import { addProducts } from '../../services/pizza'
import { toast } from 'react-toastify'
import { Link, useNavigate } from 'react-router-dom'

const ProductForm = () => {
  
  const navigate = useNavigate()
  const [product, setProduct] = useState({
    name: '',
    image: '',
    desc: '',
    category: '',
    price: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct({ ...product, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Here you can submit the product data to your backend or perform other actions
    console.log('Product submitted:', product);
    const result = await addProducts(product)
    navigate('/AdminPage')
    toast.success('successfully created product')
  };

  return (
    <div className='row' style={{paddingLeft: '10px', paddingRight: '10px'}}>


    <div className="col-md-6">
    <b><p style={{fontSize: '20px', color: 'red', '--toastify-text-color-dark': 'red', color: '#e64b0d'}}>
 Add Product</p></b>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={product.name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label>Image URL:</label>
          <input
            type="text"
            name="image"
            value={product.image}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label>Category:</label>

          <select className='form-control'  name="category" value={product.category} onChange={handleChange} aria-placeholder='Select Category' required>
          <option value={''}>Select Category</option>       
              <option value={0}>Veg</option>
              <option value={1}>Non Veg</option>
          </select>

        </div>

        <div className="form-group">
          <label>Description:</label>
          <textarea
            type="text"
            name="desc"
            value={product.desc}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label>Price:</label>
          <input
            type="number"
            name="price"
            value={product.price}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
    <div className="col-md-6 bg-image"  style={{backgroundSize: 'cover', backgroundPosition: 'center', backgroundImage: 'url("http://localhost:3000/static/media/hero-1.63f4ac241e21bd116113.jpg")'}}>

    </div>
    </div>
  );
};

export default ProductForm;
