import react from 'react';
import { useEffect, useState } from "react";
import { getProducts, deleteProducts, editProducts } from '../../services/pizza'
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify'




const ProductTable = () => {
    const orders = [];

const handleAddProduct = () => {
    // Add logic to add a new product
    console.log('Add product clicked');
  };

  const handleUpdateProduct = () => {
    // Add logic to update an existing product
    console.log('Update product clicked');
  };

  const handleDeleteProduct = async (id) => {
    // Add logic to delete a product
    try {
      // Make the API call
      const result = await deleteProducts(id);
      console.log(id);
       toast.success('Product deleted successfully')
       try {
        // Make the API call
        const result = await getProducts();
        console.log(result);
        // toast.success('successfully created product')
        setProducts(result.data);
      } catch (error) {
        console.error('Error:', error);
      }
      
    } catch (error) {
      console.error('Error:', error);
    }
    console.log('Delete product clicked');
  };

  const handleProductPrize = async (id, price) => {

    console.log('got price ', price);
    // Add logic to delete a product
    try {
      // Make the API call
      const result = await editProducts(id, price);
      console.log(id);
      //  toast.success('Product updated successfully')
       try {
        // Make the API call
        const result = await getProducts();
        console.log(result);
        // toast.success('successfully created product')
        setProducts(result.data);
      } catch (error) {
        console.error('Error:', error);
      }
      
    } catch (error) {
      console.error('Error:', error);
    }
    console.log('Delete product clicked');
  };


  const [products, setProducts] = useState([]);
  useEffect(() => {
    const getproduct = async () => {
      try {
        // Make the API call
        const result = await getProducts();
        console.log(result);
        // toast.success('successfully created product')
        setProducts(result.data);

        products.forEach(element => {
          
        });
      } catch (error) {
        console.error('Error:', error);
      }
    };

    // Call the function
    getproduct();
  }, []);

    const tableStyle = {
        height: '55vh',
    overflowY: 'scroll',
      };
    
    return(
    <>
      
          {/* Home Section Hero Banner */}
     
         
  
  
          <div className=" p-4">
          <section className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-10">
              <h1 style={{ padding: '1px' }}>Product List</h1>
              </div>
        <div className='col-md-2'>
        <Link to={"/AdminPage"}> <button className="btn btn-block btn-primary btn-smmr-2">Add Product</button>
        </Link>
        </div>
            </div>
          </div>
        </section>
      <div className='row'>
        
        
        </div>
     <br/>
     <br/>


        {/* Main content */}
        <section className="content">
          <div className="container-fluid">
            {/* Order list table */}
            <div className="row">
              <div className="col-12">
                <div className="card">
                  <div className="card-body"  style={tableStyle}>
                    <table className="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>Sr. No</th>
                          <th>Product name</th>
                          <th>Description</th>
                          <th>Price</th>
                          <th>Image</th>
                        </tr>
                      </thead>
                      <tbody>
                        {products.map((item, index) => (
                          <tr key={item.image}>
                            <td>{index+1}</td>
                            <td>{item.productName}</td>
                            <td>{item.productDesc}</td>
                            <td>
                              <input type='text' onChange={(e) => {
                                   handleProductPrize(item.id, e.target.value) 
                              }} placeholder={products[index].productPrice} />
                             
                              </td>
                            <td><img
                          style={{ width: 100 }}
                          src={item.image}
                          alt=''
                        /></td>
                            <td>
                              {/* &nbsp;&nbsp;<button className="btn btn-secondary mr-2" onClick={handleUpdateProduct}>Update</button>&nbsp; */}
      <button className="btn btn-danger" onClick={() => handleDeleteProduct(item.id) }>Delete</button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
  
  
   
          </div>
         
  
          
  
          
  
          {/* Home Section Contact */}
          
       
      </>
    );
  };
  
  export default ProductTable;
  