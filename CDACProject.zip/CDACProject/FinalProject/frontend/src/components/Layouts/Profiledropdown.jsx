import React, { useState } from 'react';

const ProfileDropdown = () => {
  const [dropdownVisible, setDropdownVisible] = useState(false);

  const toggleDropdown = () => {
    setDropdownVisible(!dropdownVisible);
  };

  return (
    <div className="profile-dropdown">
      {/* Profile icon */}
      <div className="profile-icon" onClick={toggleDropdown}>
        <i className="bi bi-person fs-5"></i>
      </div>

      {/* Dropdown menu */}
      {dropdownVisible && (
        <div className="dropdown-menu">
          <ul>
            <li><a href="/edit-profile">Edit Profile</a></li>
            <li><a href="/orders">Orders</a></li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default ProfileDropdown;
