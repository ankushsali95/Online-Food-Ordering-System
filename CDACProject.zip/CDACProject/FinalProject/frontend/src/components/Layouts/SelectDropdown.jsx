import React, { useState } from 'react';

const SelectDropdown = () => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleSelectChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <div>
      <label htmlFor="delivery-personnel">Choose a car:</label>
      <select id="delivery-personnel" value={selectedOption} onChange={handleSelectChange}>
        <option value="">Select...</option>
        <option value="volvo">Ram Mare</option>
        <option value="saab">Sham share</option>
        <option value="mercedes">Tony stark</option>
        <option value="audi">Sham kale</option>
      </select>
      <p>Selected option: {selectedOption}</p>
    </div>
  );
};

export default SelectDropdown;
