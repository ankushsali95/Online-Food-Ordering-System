import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { signinUser } from '../../services/user'

export function Signin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const navigate = useNavigate()

  const onSignin = async () => {
    if (email.length === 0) {
      toast.warn('enter email')
    } else if (password.length === 0) {
      toast.warn('enter password')
    } else {
      // make the api call
      const result = await signinUser(email, password)
      console.log(result)
      if (result?.data?.token) {
        // cache the token
        const token = result['data']['token']
        const role = result['data']['usertype']
        const myuid = result['data']['myuid']
        
        sessionStorage['token'] = token
        sessionStorage['myuid'] = myuid
        sessionStorage['username'] = email

        toast.success('Welcome to the Burger shop')
        if(role == 1){
          navigate('/AdminDashboardPage')
        }else{
          navigate('/FrontPage')
        }
       
      } else {
        toast.error(result?.error?.response?.data?.message)
      }
    }
  }

  return (
    <>
      <h2 className='title' text-center  style={{ textAlign: 'center', color: '#0b5ed7' }}>Signin</h2>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>
            <div className='mb-3'>
              <label htmlFor=''>Email</label>
              <input
                onChange={(e) => setEmail(e.target.value)}
                type='email'
                placeholder='abc@test.com'
                className='form-control'
              />
            </div>
            <div className='mb-3'>
              <label htmlFor=''>Password</label>
              <input
                onChange={(e) => setPassword(e.target.value)}
                type='password'
                placeholder='xxxxxxxx'
                className='form-control'
              />
            </div>
            <div className='mb-3'>
              <div>
                Don't have an account? <Link to='/Signup'>Signup here</Link>
              </div>
              <button onClick={onSignin} className='btn btn-primary mt-2' >
                Signin
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </>
  )
}

export default Signin
