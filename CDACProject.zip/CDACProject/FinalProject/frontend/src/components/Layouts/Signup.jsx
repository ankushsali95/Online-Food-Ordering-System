import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { signupUser } from '../../services/user'

export function Signup() {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [mobile, setMobile] = useState('')
  const [address, setAddress] = useState('')
  const [pincode, setPincode] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  // get the navigation function
  const navigate = useNavigate()
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValidMobile = (mobile) => {
    // Mobile validation criteria, you can customize as per your requirements
    const mobileRegex = /^[0-9]{10}$/; // Matches a 10-digit number
    return mobileRegex.test(mobile);
  };

  const isValidPincode = (pincode) => {
    // Pincode validation criteria, you can customize as per your requirements
    const pincodeRegex = /^\d{6}$/; // Matches a 6-digit pincode
    return pincodeRegex.test(pincode);
  };




  const onSignup = async () => {
    if (firstName.length == 0) {
      toast.warn('enter first name')
    } else if (lastName.length == 0) {
      toast.warn('enter last name')
    } else if (!emailRegex.test(email)) {
      toast.warn('enter a valid email')
    } else if (password.length == 0) {
      toast.warn('enter password')
    } else if (confirmPassword.length == 0) {
      toast.warn('enter confirm password')
    } else if (password != confirmPassword) {
      toast.warn('password does not match')
    }else if(address.length == 0) {
      toast.warn('Enter Address')
    }else if (!isValidMobile(mobile)) {
      toast.warn('Enter a valid mobile number')
    }else if (!isValidPincode(pincode)) {
      toast.warn('Enter a valid pincode');
    }else {
      // make the api call
      const result = await signupUser(firstName, lastName, email, password, address, mobile, pincode)

      if (result.status != 'error') {
        toast.success('Successfully registered the user')
        navigate('/')
      } else {
        toast.error("Please try again after some time")
      }
    }
  }

  return (
    <>
       <h2 className='title' style={{ textAlign: 'center', color: '#0b5ed7' }}>Signup</h2>
       &nbsp;

       <div className='row justify-content-center'>
  <div className='col-md-3'>
    <div className='form'>
      <div className='mb-3'>
        <label htmlFor=''>First Name</label>
        <input
          onChange={(e) => setFirstName(e.target.value)}
          type='text'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Last Name</label>
        <input
          onChange={(e) => setLastName(e.target.value)}
          type='text'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Email</label>
        <input
          onChange={(e) => setEmail(e.target.value)}
          type='email'
          placeholder='abc@test.com'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Mobile Number</label>
        <input
          onChange={(e) => setMobile(e.target.value)}
          type='text'
          placeholder='Your mobile number'
          className='form-control'
        />
      </div>
     
    </div>
  </div>
  <div className='col-md-3'>
    <div className='form'>
      <div className='mb-3'>
        <label htmlFor=''>Address</label>
        <textarea
           onChange={(e) => setAddress(e.target.value)}
          type='text'
          placeholder='Your address'
          className='form-control'
        />
      </div>

      <div className='mb-3'>
        <label htmlFor=''>Pincode</label>
        <input
          onChange={(e) => setPincode(e.target.value)}
          type='text'
          placeholder='Pincode'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Password</label>
        <input
          onChange={(e) => setPassword(e.target.value)}
          type='password'
          placeholder='xxxxxxxx'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Confirm Password</label>
        <input
          onChange={(e) => setConfirmPassword(e.target.value)}
          type='password'
          placeholder='xxxxxxxx'
          className='form-control'
        />
      </div>
      
    </div>
  </div>
</div>
<div className='row pl-10' width='10%' >
 
       
        <div className='col-5'></div>
        <div className='col-5'>
        
        <div className='col-4'>
        <div style={{ textAlign: 'center' }}>
          Already got an account? <Link to='/Signin'>Sign in here</Link>
          &nbsp;
        </div>
          <div  style={{ textAlign: 'center' }}>
          <button className="btn btn-primary mr-" onClick={onSignup} >
          Signup
        </button>
          </div>
        </div>
        </div>
        <div className='col-5'></div>
      </div>
    </>
  )
}

export default Signup
