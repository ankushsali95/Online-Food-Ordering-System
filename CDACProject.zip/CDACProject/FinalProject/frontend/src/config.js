module.exports = {
  server: 'https://localhost:7134',
}
