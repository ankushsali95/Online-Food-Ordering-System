import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Burger from "../../assets/hero/hero-2.png";
import { Link } from "react-router-dom";
import Signup from "../../components/Layouts/Signup"
import { useState, useEffect } from "react";
import AdminSidebar from "../../components/Layouts/AdminSidebar";
import Layout from "../../components/Layouts/Layout";
import AdminHeader from "../../components/Layouts/AdminHeader";
import AdminDashboard from "../../components/Layouts/AdminDashboard";
import ProductForm from "../../components/Layouts/ProductForm";
import RevenueChart from "../../components/Layouts/RevenueChart";
import OrderPage from "./OrderPage";
import OrderTable from "../../components/Layouts/OrderTable";
import TransactionTable from "../../components/Layouts/TransactionTable";
import { getRevenue } from "../../services/order";

const AdminDashboardPage = () => {

  const [revenue, setRevenue] = useState({
    revenue: '',
    monthlyRevenue: '',
    orderCount: '',
    monthlyOrderCount: ''
 
  });

  const loadRevenue = async () => {
    const result = await getRevenue()
    console.log(result);
    setRevenue(result);
  }
    const tableStyle = {
        height: '55vh',
    overflowY: 'scroll',
      };

      useEffect(() => {
        loadRevenue()
      }, [])
    

  return (
    <>
      <div id="wrapper">
        {/* Home Section Hero Banner */}

        <AdminSidebar />
        <AdminHeader />



        <div className="content-wrapper p-4">
          <AdminDashboard />
          <div className="row">
            <div className="col-lg-3 col-6">
              <div className="small-box bg-info">
                <div className="inner">
                  <h3>₹ {revenue.revenue ?? 0.00}</h3>
                  <p>Monthly revenue</p>
                </div>
                <div className="icon">
                  <i className="ion ion-bag"></i>
                </div>
                <a href="#" className="small-box-footer"> <i className="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>

            <div className="col-lg-3 col-6">
              <div className="small-box bg-success">
                <div className="inner">
                  <h3>₹ {revenue.monthlyRevenue ?? 0.00}</h3>
                  <p>Total revenue</p>
                </div>
                <div className="icon">
                  <i className="ion ion-stats-bars"></i>
                </div>
                <a href="#" className="small-box-footer"><i className="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>

            <div className="col-lg-3 col-6">
              <div className="small-box bg-warning">
                <div className="inner">
                  <h3>{revenue.orderCount ?? 0}</h3>
                  <p>Orders/month</p>
                </div>
                <div className="icon">
                  <i className="ion ion-person-add"></i>
                </div>
                <a href="#" className="small-box-footer"> <i className="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>

            <div className="col-lg-3 col-6">
              <div className="small-box bg-danger">
                <div className="inner">
                  <h3>{revenue.monthlyOrderCount ?? 0}</h3>
                  <p>Total orders</p>
                </div>
                <div className="icon">
                  <i className="ion ion-pie-graph"></i>
                </div>
                <a href="#" className="small-box-footer"><i className="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
          </div>


         <TransactionTable/>

        </div>





        {/* Home Section Contact */}


      </div>
    </>
  );
};

export default AdminDashboardPage;
