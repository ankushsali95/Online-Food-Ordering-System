import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom'; // Import useParams hook to access URL parameters
import { toast } from 'react-toastify';
import { getSingleOrders } from '../../services/order';
import Header from '../../components/Layouts/Header';
import AdminSidebar from '../../components/Layouts/AdminSidebar';
import AdminHeader from '../../components/Layouts/AdminHeader';


export function Allordersdetails() {
  const [order, setOrder] = useState({});
  const { orderId } = useParams(); // Get the orderId from URL parameters

  const loadOrder = async () => {
    try {
      const result = await getSingleOrders(orderId); // Fetch order using the URL parameter
      console.log(result);
      setOrder(result);
    } catch (error) {
      console.error('Error fetching order:', error);
      toast.error('Failed to fetch order details');
    }
  };

  useEffect(() => {
    loadOrder();
  }, [orderId]); // Trigger loadOrder whenever orderId changes

  return (
    <>
    <AdminSidebar/>
      <AdminHeader />
     
      <div className="content-wrapper p-4">
      <div className='container'>
        <h1 className='mt-4'>Order Details</h1>
        <div className='card mt-4'>
          <div className='card-body'>
            <p className='card-text'>Order ID: {order.orderId ?? 1}</p>
            <p className='card-text'>Order Date: {new Date(order.orderDate).toLocaleString()}</p>
            <p className='card-text'>Username: {order.username}</p>
            <p className='card-text'>Order Total(Tax inclusive): ₹{(order.orderTotal*1.05).toFixed(2)}</p>
          </div>
        </div>
        <h2 className='mt-4'>Order Items:</h2>
        <div className='list-group'>
          {order.orderItems &&
            order.orderItems.map((item, index) => (
              <div key={index} className='list-group-item'>
                <div className='d-flex w-100 justify-content-between'>
                  <h5 className='mb-1'>{item.productName}</h5>
                  <small>Price: ₹{item.price}</small>
                </div>
                <p className='mb-1'>Quantity: {item.quantity}</p>
              </div>
            ))}
        </div>
      </div>
      </div>
    </>
  );
}

export default Allordersdetails;
