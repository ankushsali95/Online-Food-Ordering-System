import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import Header from "../../components/Layouts/Header";
import Footer from "../../components/Layouts/Footer";


function Contact() {
  return (

    <>
     <Header/>
     
    <section className="contact_section">
      <Container>
        <Row className="justify-content-center">
          <Col sm={8} className="text-center">
            <h4>We Guarantee</h4>
            <h2>30 Minutes Delivery!</h2>
            <p><b>
            Experience the thrill of swift service with our lightning-fast delivery 
            – because we believe in getting your order to you at the speed of now!
            </b></p>
            
          </Col>
        </Row>
      </Container>

      

    </section>
 



    <Footer />
    </>
  );
}

export default Contact;
