import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Burger from "../../assets/hero/hero-2.png";
import { Link } from "react-router-dom";
import Signup from "../../components/Layouts/Signup"
import { useState,useEffect } from "react";

const FirstPage = () => {
  const [value, setValue] = useState(null)

    useEffect(() => { console.log("hello")
  setValue(localStorage.getItem('email'));
  }) 
  return (
    <section className="hero_section">
      <Container>
        <Row>
          
          <Col lg={5}>
            <div className="hero_text text-center">
              <h1 className="text-white">Delight </h1>
              <h2 className="text-white"> in every bite!</h2>
              <p className="text-white pt-2 pb-4">
              Welcome to Hungry Buddy! Bringing Your Favorite Meals to Your Doorstep!
              Discover a World of Culinary Delights, Delivered Fast and Fresh
              </p>
              <Link to={ sessionStorage.token ? "/Menu": "/Signin"} className="btn order_now" style={{ transition: 'background-color 0.3s ease' }}>
                Order Now
              </Link>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default FirstPage;
