import React from "react";
import Layout from "../../components/Layouts/Layout";
import "../../styles/HomeStyle.css";
import FirstPage from "./FirstPage";
import Section2 from "./Section2";


import {useState,useEffect} from 'react';


const Home = () => {
  const [value, setValue] = useState(null)

    useEffect(() => { console.log("hello")
  setValue(localStorage.getItem('email'));
  }) 
  return (
    <>
      <Layout>
        {/* Home Section Hero Banner */}
        {!value && (
        <FirstPage />)}

        {/* Home Section About */}
        < Section2/>

        

        

        {/* Home Section Contact */}
        
      </Layout>
    </>
  );
};

export default Home;
