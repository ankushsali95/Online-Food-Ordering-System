import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Image1 from "../../assets/menu/burger-11.jpg";
import Image2 from "../../assets/menu/burger-12.jpg";
import Image3 from "../../assets/menu/burger-13.jpg";
import Image4 from "../../assets/menu/burger-14.jpg";
import Image5 from "../../assets/menu/burger-15.jpg";
import Image6 from "../../assets/menu/burger-16.jpg";
import Image7 from "../../assets/menu/burger-17.jpg";
import Image8 from "../../assets/menu/burger-18.jpg";
import image1 from "../../assets/menu/hamburger-8026582_640.jpg";
import image2 from "../../assets/menu/sandwich-5930496_640.jpg";
import image3 from "../../assets/menu/burger-3962997_640.jpg";
import image4 from "../../assets/menu/hamburger-1238246_640.jpg";
import image5 from "../../assets/menu/hamburger-1238246_1280.jpg";
import image6 from "../../assets/menu/hamburger-1414422_640.jpg";
import image7 from "../../assets/menu/hamburger-5630646_640.jpg";

import Cards from "../../components/Layouts/Cards";
import { Link } from "react-router-dom";
import Header from "../../components/Layouts/Header";
import Footer from "../../components/Layouts/Footer";
import { useEffect, useState } from "react";
import { getProducts } from '../../services/pizza'




// Mock Data Cards
const mockData = [
  // Add more mock data objects as needed
];

// Rating Logical Data
const renderRatingIcons = (rating) => {
  const stars = [];

  for (let i = 0; i < 5; i++) {
    if (rating > 0.5) {
      stars.push(<i key={i} className="bi bi-star-fill"></i>);
      rating--;
    } else if (rating > 0 && rating < 1) {
      stars.push(<i key={"half"} className="bi bi-star-half"></i>);
      rating--;
    } else {
      stars.push(<i key={`empty${i}`} className="bi bi-star"></i>);
    }
  }
  return stars;
};

function Menu() {
  const [products, setProducts] = useState([]);
  const [showVeg, setShowVeg] = useState(true);
  const [showNonVeg, setShowNonVeg] = useState(true);
  useEffect(() => {
    const getproduct = async () => {
      try {
        // Make the API call
        const result = await getProducts();
        console.log(result);
        setProducts(result.data);
      } catch (error) {
        console.error('Error:', error);
      }
    };

    // Call the function
    getproduct();
  }, []);

//filter for veg non veg
const filteredProducts = products.filter(product => {
  return (showVeg==true && (product.productType==0)) || (showNonVeg==true && (product.productType==1));
});

  return (

    <>
    <Header />
    <section className="menu_section" id="menu-section">
      <Container>
        <Row>
          <Col lg={{ span: 8, offset: 2 }} className="text-center mb-5">
            <h2>OUR CRAZY MENU</h2>
            <p className="para">
            Explore our diverse menu and select your favorite dishes!
            </p>
          </Col>
        </Row>



        {/* Filter buttons */}
         <Row>
            <Col className="text-center">
              Search by: &nbsp;
              <button onClick={() => setShowVeg(!showVeg)} className={`btn btn-sm ${showVeg ? 'btn-success' : 'btn-outline-success'} me-2`}>
                Veg
              </button>
              <button onClick={() => setShowNonVeg(!showNonVeg)} className={`btn btn-sm ${showNonVeg ? 'btn-danger' : 'btn-outline-danger'}`}>
                Non-Veg
              </button>
              <br/><br/>
            </Col>
          </Row>



        <Row>
          {filteredProducts.map((cardData, index) => (
            <Cards
              key={index}
              image={cardData.image}
              //rating={cardData.rating}
              title={cardData.productName}
              paragraph={cardData.productDesc}
              price={cardData.productPrice}
              cid={cardData.id}
              //renderRatingIcons={renderRatingIcons}
            />
          ))}
        </Row>

        
      </Container>

    </section>
    <Footer />
    </>
  );
}

export default Menu;
