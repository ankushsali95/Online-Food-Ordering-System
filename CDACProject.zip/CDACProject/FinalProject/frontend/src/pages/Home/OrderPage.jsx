import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Burger from "../../assets/hero/hero-2.png";
import { Link } from "react-router-dom";
import Signup from "../../components/Layouts/Signup"
import { useState,useEffect } from "react";
import AdminSidebar from "../../components/Layouts/AdminSidebar";
import Layout from "../../components/Layouts/Layout";
import AdminHeader from "../../components/Layouts/AdminHeader";
import AdminDashboard from "../../components/Layouts/AdminDashboard";
import ProductForm from "../../components/Layouts/ProductForm";
import OrderTable from "../../components/Layouts/OrderTable";

const OrderPage = () => {
  
  return(
  <>
    
        {/* Home Section Hero Banner */}
   
        <AdminSidebar />
        <AdminHeader/>
        <div className="content-wrapper p-4">
        <OrderTable />
        </div>

       
    </>
  );
};

export default OrderPage;
