import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import Pizza from "../../assets/menu/hamburger-5630646_640.jpg";
import Salad from "../../assets/menu/hamburger-1414422_640.jpg";
import Delivery from "../../assets/menu/burger-3962997_640.jpg";

// Mock Data Cards
const mockData = [
  {
    image: Pizza,
    title: "Original",
    paragraph: `Unlock exclusive deals and discounts when you order with us. Enjoy great savings on your favorite meals`,
  },
  {
    image: Salad,
    title: "Qualty Foods",
    paragraph: `Unlock exclusive deals and discounts when you order with us. Enjoy great savings on your favorite meals`,
  },
  {
    image: Delivery,
    title: "Fastest Delivery",
    paragraph: `Unlock exclusive deals and discounts when you order with us. Enjoy great savings on your favorite meals`,
  },
  // Add more mock data objects as needed
];

function Section2() {
  return (
    <>
      <section >
        <Container>
          <Row>
            <Col lg={{ span: 1, offset: 2 }} className="text-center">
              {/* <h2>The burger tastes better when you eat it with your family</h2> */}
              {/* <p>
                Porta semper lacus cursus, feugiat primis ultrice a ligula risus
                auctor an tempus feugiat dolor lacinia cubilia curae integer
                orci congue and metus integer primis in integer metus
              </p> */}
             
            </Col>
          </Row>
        </Container>
      </section>
      <section className="about_wrapper">
        <Container>
          <Row className="justify-content-md-center">
            {mockData.map((cardData, index) => (
              <Col md={6} lg={4} className="mb-4 mb-md-0" key={index}>
                <div className="about_box text-center">
                  <div className="about_icon">
                    <img
                      src={cardData.image}
                      className="img-fluid"
                      alt="icon"
                    />
                  </div>
                  <h4>{cardData.title}</h4>
                  <p>{cardData.paragraph}</p>
                </div>
              </Col>
            ))}
          </Row>
        </Container>
      </section>
    </>
  );
}

export default Section2;
