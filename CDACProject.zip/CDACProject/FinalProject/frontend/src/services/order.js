import axios from 'axios'
import { createError, createUrl } from './utils'

export async function placeOrder(items, totalAmount) {
  try {
    const url = createUrl('api/createOrder')
    const headers = {
      headers: {
        token: sessionStorage['token'],
      },
    }
    const body = 

    {
      "orderId": 0,
      "orderDate": "2024-02-17T08:00:00Z",
      "orderStatus": 1,
      "orderTotal": totalAmount,
      "paymentMethod": 1,
      "userId": sessionStorage.myuid,
      "orderItems": 
        items.map((item) => {
          return {
            productId: item['id'],
            quantity: item['quantity'],
            price: item['quantity'] * item['price'],
          }
        })
      
    }
    

    const response = await axios.post(url, body, headers)
    return response.data
  } catch (ex) {
    return createError(ex)
  }
}

export async function getAllOrders() {
  try {
    const url = createUrl('api/orders')
    const headers = {
      headers: {
        token: sessionStorage['token'],
      },
    }

    const response = await axios.get(url, headers)
    return response.data
  } catch (ex) {
    return createError(ex)
  }
}


export async function getSingleOrders(id) {
  try {
    const url = createUrl('api/singleOrder/'+id)
    const headers = {
      headers: {
        token: sessionStorage['token'],
      },
    }

    const body = {
      id: id
    }
    const response = await axios.post(url,body,  headers)
    return response.data
  } catch (ex) {
    return createError(ex)
  }
}

export async function getRevenue() {
  try {
    const url = createUrl('api/revenue')
    const headers = {
      headers: {
        token: sessionStorage['token'],
      },
    }

    const response = await axios.get(url, headers)
    return response.data
  } catch (ex) {
    return createError(ex)
  }
}
