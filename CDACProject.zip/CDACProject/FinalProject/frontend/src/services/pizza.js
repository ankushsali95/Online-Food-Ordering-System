import axios from 'axios'
import { createError, createUrl } from './utils'

export async function getAllPizzas() {
  try {
    const url = createUrl('/api/products')
    const headers = {
      headers: {
        token: sessionStorage['token'],
      },
    }
    const response = await axios.get(url, headers)
    return response.data
  } catch (ex) {
    return createError(ex)
  }
}

export async function getProducts() {
  try {
    const url = createUrl('api/products')
    const body = {
    }
    const response = await axios.get(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}


export async function addProducts(product) {
  try {
    const url = createUrl('api/addProduct')
    const body = {
      "id": 0,
      "productName": product.name,
      "productType": product.category,
      "productPrice": product.price,
      "productDesc": product.desc,
      "image": product.image
    }
    const response = await axios.post(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}


export async function deleteProducts(id) {
  try {
    console.log(id, 'id');
    const url = createUrl('api/DeleteProduct/'+id)
    const body = {
    }
    const response = await axios.delete(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}

export async function editProducts(id, price) {
  try {
    console.log(id, 'id');
    const url = createUrl('api/EditProduct/'+id)
    const body = {
      "id": id,
      "productName": "string",
      "productType": 0,
      "productPrice": price,
      "productDesc": "string",
      "image": "string"
    }
    const response = await axios.put(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}



