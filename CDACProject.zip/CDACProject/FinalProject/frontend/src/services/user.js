import axios from 'axios'
import { createError, createUrl } from './utils'

export async function signupUser(firstName, lastName, email, password, address, mobile, pincode) {
  console.log(mobile);
  console.log(typeof mobile);
  try {
    const url = createUrl('api/signup')
    const body = {
  
  username :email,
  email: email,
  password: password,
  first_name: firstName,
  last_name: lastName,
  mobile_no: mobile.toString(),
  address: address,
  pincode: pincode,
  date_of_birth: "2024-02-17T18:00:11.223Z",
  gender: "Male",
  created_at: "2024-02-17T18:00:11.223Z",
  updated_at: "2024-02-17T18:00:11.223Z",
  status: "Active",
  last_login_at: "2024-02-17T18:00:11.223Z",
  role_id: 2
    }
    const response = await axios.post(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}

export async function signinUser(email, password) {
  try {
    const url = createUrl('api/login')
    const body = {
      email: email,
      password: password,
    }
    const response = await axios.post(url, body)
    return response
  } catch (ex) {
    return createError(ex)
  }
}


