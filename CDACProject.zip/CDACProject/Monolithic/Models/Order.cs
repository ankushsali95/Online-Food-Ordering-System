namespace TFLPortal.Models;

public class Order
{
    
    public int OrderId { get; set; }
    public DateTime OrderDate { get; set; }

    public int ProductType { get; set; }

    public int OrderStatus { get; set; }

    public Double OrderTotal { get; set; }

    public int payment_method  { get; set; }

    public int UserId { get; set; }

    public List<OrderItem> OrderItems { get; set; }







}
