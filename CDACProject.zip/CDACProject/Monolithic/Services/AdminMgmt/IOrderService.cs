using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
//using TFLPortal.Responses;


namespace TFLPortal.Services.AdminMgmt;

public interface IOrderService
{
    Task<List<Order>> GetAllOrders();

    //Task<bool> AddProduct(Product product);

    //Task<bool> EditProduct(Product product);


    //Task<bool> DeleteProduct(int id);


}
