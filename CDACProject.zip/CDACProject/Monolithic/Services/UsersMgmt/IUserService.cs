using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
//using TFLPortal.Responses;


namespace TFLPortal.Services.UsersMgmt;

public interface IUserService
{
    Task<List<User>> GetAllUsers();
    Task<string> GetUserPasswordHashAsync(string username);
    Task<bool> AddUser(User user);

  Task<bool> EditUser(User user);

   Task<bool> DeleteUser(int userId);
    
}



