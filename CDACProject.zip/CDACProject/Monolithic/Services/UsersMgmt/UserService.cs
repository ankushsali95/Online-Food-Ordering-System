using MySql.Data.MySqlClient;
using TFLPortal.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;


namespace TFLPortal.Services.UsersMgmt;

public class UserService : IUserService
{
    private readonly IConfiguration _configuration;
    private readonly string _connectionString;

    public UserService(IConfiguration configuration)
    {
        _configuration = configuration;
        _connectionString =
            _configuration.GetConnectionString("DefaultConnection")
            ?? throw new ArgumentNullException("connectionString");
    }

    public async Task<List<User>> GetAllUsers()
    {
        List<User> users = new List<User>();
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            string query =
              @"SELECT * from users";
            MySqlCommand command = new MySqlCommand(query, connection);
           

            
            await connection.OpenAsync();
            MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                User user = new User()
                {
                    // Id = reader.GetInt32(reader.GetOrdinal("id")),
                    // Username = reader.GetString(reader.GetOrdinal("username")),
                    // Email = reader.GetString(reader.GetOrdinal("email")),
                    // Password = reader.GetString(reader.GetOrdinal("password_hash")),
                    // First_name = reader.GetString(reader.GetOrdinal("first_name")),
                    // Last_name = reader.GetString(reader.GetOrdinal("last_name")),
                    //  Mobile_no = reader.GetInt32(reader.GetOrdinal("mobile_no")),
                    // Address = reader.GetString(reader.GetOrdinal("address")),
                    // Pincode = reader.GetInt32(reader.GetOrdinal("pincode")),
                    // Date_of_birth = reader.GetDateTime(reader.GetOrdinal("date_of_birth")),
                    // Gender = reader.GetString(reader.GetOrdinal("gender")),
                    // Created_at = reader.GetDateTime(reader.GetOrdinal("created_at")),
                    // Updated_at = reader.GetDateTime(reader.GetOrdinal("updated_at")),
                    // Status = reader.GetString(reader.GetOrdinal("status")),
                    // Last_login_at = reader.GetDateTime(reader.GetOrdinal("datetime")),
                    // Role_id = reader.GetInt32(reader.GetOrdinal("role_id"))

                    Id = reader.IsDBNull(reader.GetOrdinal("id")) ? 0 : reader.GetInt32(reader.GetOrdinal("id")),
                    Username = reader.IsDBNull(reader.GetOrdinal("username")) ? string.Empty : reader.GetString(reader.GetOrdinal("username")),
                    Email = reader.IsDBNull(reader.GetOrdinal("email")) ? string.Empty : reader.GetString(reader.GetOrdinal("email")),
                    Password = reader.IsDBNull(reader.GetOrdinal("password_hash")) ? string.Empty : reader.GetString(reader.GetOrdinal("password_hash")),
                    First_name = reader.IsDBNull(reader.GetOrdinal("first_name")) ? string.Empty : reader.GetString(reader.GetOrdinal("first_name")),
                    Last_name = reader.IsDBNull(reader.GetOrdinal("last_name")) ? string.Empty : reader.GetString(reader.GetOrdinal("last_name")),
                    Mobile_no = reader.IsDBNull(reader.GetOrdinal("mobile_no")) ? 0 : reader.GetInt32(reader.GetOrdinal("mobile_no")),
                    Address = reader.IsDBNull(reader.GetOrdinal("address")) ? string.Empty : reader.GetString(reader.GetOrdinal("address")),
                    Pincode = reader.IsDBNull(reader.GetOrdinal("pincode")) ? 0 : reader.GetInt32(reader.GetOrdinal("pincode")),
                    Date_of_birth = reader.IsDBNull(reader.GetOrdinal("date_of_birth")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("date_of_birth")),
                    Gender = reader.IsDBNull(reader.GetOrdinal("gender")) ? string.Empty : reader.GetString(reader.GetOrdinal("gender")),
                    Created_at = reader.IsDBNull(reader.GetOrdinal("created_at")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("created_at")),
                    Updated_at = reader.IsDBNull(reader.GetOrdinal("updated_at")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("updated_at")),
                    Status = reader.IsDBNull(reader.GetOrdinal("status")) ? string.Empty : reader.GetString(reader.GetOrdinal("status")),
                    Last_login_at = reader.IsDBNull(reader.GetOrdinal("last_login_at")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("last_login_at")),
                    Role_id = reader.IsDBNull(reader.GetOrdinal("role_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("role_id"))
                };
                users.Add(user);
            }
            await reader.CloseAsync();
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            await connection.CloseAsync();
        }
        return users;
    }


    public async Task<bool> AddUser(User user)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText =
                "Insert into users (id, username,email,password_hash,first_name,last_name,mobile_no,address,pincode,date_of_birth,gender, created_at,updated_at,status,last_login_at,role_id) " +
                "values(@id, @username,@email,@password_hash,@first_name,@last_name, @mobile_no, @address, @pincode, @date_of_birth, @gender, @created_at, @updated_at, @status,@last_login_at, @role_id)";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", user.Id);
            command.Parameters.AddWithValue("@username", user.Username);
            command.Parameters.AddWithValue("@email", user.Email);
            command.Parameters.AddWithValue("@password_hash", user.Password);
            command.Parameters.AddWithValue("@first_name", user.First_name);
            command.Parameters.AddWithValue("@last_name", user.Last_name);
            command.Parameters.AddWithValue("@mobile_no", user.Mobile_no);
            command.Parameters.AddWithValue("@address", user.Address);
            command.Parameters.AddWithValue("@pincode", user.Pincode);
            command.Parameters.AddWithValue("@date_of_birth", user.Date_of_birth);
            command.Parameters.AddWithValue("@gender", user.Gender);
            command.Parameters.AddWithValue("@created_at", user.Created_at);
            command.Parameters.AddWithValue("@updated_at", user.Updated_at);
            command.Parameters.AddWithValue("@status", user.Status);
            command.Parameters.AddWithValue("@last_login_at", user.Last_login_at);
            command.Parameters.AddWithValue("@role_id", user.Role_id);
            

            int rowsAffected = await command.ExecuteNonQueryAsync(); // Execute the query asynchronously

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }

    public async Task<string> GetUserPasswordHashAsync(string username)
    {
        string passwordHash = null;
        using (MySqlConnection connection = new MySqlConnection(_connectionString))
        {
            try
            {
                await connection.OpenAsync();

                MySqlCommand command = new MySqlCommand(
                    "SELECT password_hash FROM users WHERE username = @username",
                    connection);
                command.Parameters.AddWithValue("@username", username);

                object result = await command.ExecuteScalarAsync(); // Execute the query asynchronously

                if (result != null)
                {
                    passwordHash = result.ToString();
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., log the error)
                Console.WriteLine($"Error fetching password hash for user '{username}': {ex.Message}");
            }
        }

        return passwordHash;
    }


    
    public async Task<bool> EditUser(User user)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText =
                "UPDATE users " +
                "SET username = @username, " +
                "email = @email, " +
                "password_hash = @password_hash, "+
                 "first_name = @first_name, " +
                 "last_name = @last_name, " +
                 "mobile_no = @mobile_no, " +
                 "address = @address, " +
                 "pincode = @pincode, " +
                 "date_of_birth = @date_of_birth, " +
                 "gender = @gender, " +
                 "created_at = @created_at, " +
                 "updated_at = @updated_at, " +
                 "status = @status, " +
                 "last_login_at = @last_login_at, " +
                 "role_id = @role_id " +
                 "WHERE id = @id";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", user.Id);
            command.Parameters.AddWithValue("@username", user.Username);
            command.Parameters.AddWithValue("@email", user.Email);
            //command.Parameters.AddWithValue("@password_hash", user.Password);
            command.Parameters.AddWithValue("@first_name", user.First_name);
            command.Parameters.AddWithValue("@last_name", user.Last_name);
            command.Parameters.AddWithValue("@mobile_no", user.Mobile_no);
            command.Parameters.AddWithValue("@address", user.Address);
            command.Parameters.AddWithValue("@pincode", user.Pincode);
            command.Parameters.AddWithValue("@date_of_birth", user.Date_of_birth);
            command.Parameters.AddWithValue("@gender", user.Gender);
            command.Parameters.AddWithValue("@created_at", user.Created_at);
            command.Parameters.AddWithValue("@updated_at", user.Updated_at);
            command.Parameters.AddWithValue("@status", user.Status);
            command.Parameters.AddWithValue("@last_login_at", user.Last_login_at);
            command.Parameters.AddWithValue("@role_id", user.Role_id);

            int rowsAffected = await command.ExecuteNonQueryAsync(); 

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }



    public async Task<bool> DeleteUser(int userId)
    {
        bool status = false;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = _connectionString;
        try
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM users WHERE id = @id";
            command.Connection = connection;
            await connection.OpenAsync();
            command.Parameters.AddWithValue("@id", userId);

            int rowsAffected = await command.ExecuteNonQueryAsync(); // Execute the query asynchronously

            if (rowsAffected > 0)
            {
                status = true;
            }
        }
        catch (Exception ee)
        {
            throw ee;
        }
        finally
        {
            connection.Close();
        }

        return status;
    }





}
